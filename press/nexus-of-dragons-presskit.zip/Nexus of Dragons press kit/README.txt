Nexus of Dragons - press kit
Developer and publisher: Highmarch Games - https://highmarchgames.com
Press contact: contact@highmarchgames.com

screens/  work-in-progress screenshots (everything shown may change before release)
art/      game logo, game icon, key art, studio logos (PNG and SVG)

All images may be used in coverage of Nexus of Dragons.
